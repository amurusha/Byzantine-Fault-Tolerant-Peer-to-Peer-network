/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
* Copyright (c) 2015 Janaka Wijekoon, Hiroaki Nishi Laboratory, Keio University, Japan
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License version 2 as 
* published by the Free Software Foundation;
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*
* Author: Janaka Wijekoon <janaka@west.sd.ekio.ac.jp>, Hiroaki Nishi <west@sd.keio.ac.jp>
*/

#include "dvrp-helper.h"

#include "ns3/dvrp.h"
#include "ns3/node.h"
#include "ns3/node-list.h"
#include "ns3/names.h"
#include "ns3/ipv4-list-routing.h"

namespace ns3 {

DVRPHelper::DVRPHelper () : Ipv4RoutingHelper ()
                            
{
  m_factory.SetTypeId ("ns3::DVRPRoutingProtocol");
}

DVRPHelper::DVRPHelper (const DVRPHelper &o): m_factory (o.m_factory)
{
  m_interfaceExclusions = o.m_interfaceExclusions;
}

DVRPHelper::~DVRPHelper ()
{
  m_interfaceExclusions.clear ();
}

DVRPHelper* 
DVRPHelper::Copy (void) const
{
  return new DVRPHelper (*this);
}

Ptr<Ipv4RoutingProtocol>
DVRPHelper::Create (Ptr<Node> node) const
{
  Ptr<DVRPRoutingProtocol> DVRPRouteProto = m_factory.Create<DVRPRoutingProtocol> ();

  std::map<Ptr<Node>, std::set<uint32_t> >::const_iterator it = m_interfaceExclusions.find (node);

  if(it != m_interfaceExclusions.end ())
  {
    DVRPRouteProto->SetInterfaceExclusions (it->second);
  }

  node->AggregateObject (DVRPRouteProto);
  return DVRPRouteProto;
}

void
DVRPHelper::Set (std::string name, const AttributeValue &value)
{
  m_factory.Set (name, value);
} 

int64_t
DVRPHelper::AssignStreams (NodeContainer c, int64_t stream)
{
  int64_t currentStream = stream;
  Ptr<Node> node;
  for (NodeContainer::Iterator i = c.Begin (); i != c.End (); ++i)
  {
    node = (*i);
    Ptr<Ipv4> ipv4 = node->GetObject<Ipv4> ();
    NS_ASSERT_MSG (ipv4, "Ipv4 not installed on node");
    
    Ptr<Ipv4RoutingProtocol> rProto = ipv4->GetRoutingProtocol ();
    NS_ASSERT_MSG (rProto, "Ipv4 routing not installed on node");
    
    Ptr<DVRPRoutingProtocol> DVRP = DynamicCast<DVRPRoutingProtocol> (rProto);
    if (DVRP)
    {
      currentStream += DVRP->AssignStreams (currentStream);
      continue;
    }
    
    // DVRP may also be in a list
    Ptr<Ipv4ListRouting> routeList = DynamicCast<Ipv4ListRouting> (rProto);
    if (routeList)
    {
      int16_t priority;
      Ptr<Ipv4RoutingProtocol> listIpv4Proto;
      Ptr<DVRPRoutingProtocol> listDVRP;
      
      for (uint32_t i = 0; i < routeList->GetNRoutingProtocols (); i++)
      {
        listIpv4Proto = routeList->GetRoutingProtocol (i, priority);
        listDVRP = DynamicCast<DVRPRoutingProtocol> (listIpv4Proto);
        
        if (listDVRP)
        {
          currentStream += DVRP->AssignStreams (currentStream);
          break;
        }
      }
    }
  }
  return (currentStream - stream);
}

void DVRPHelper::SetDefRoute (Ptr<Node> node, Ipv4Address nextHop, uint32_t interface)
{
  Ptr<Ipv4> ipv4 = node->GetObject<Ipv4> ();
  NS_ASSERT_MSG (ipv4, "Ipv4 not installed on node");
  
  Ptr<Ipv4RoutingProtocol> rProto = ipv4->GetRoutingProtocol ();
  NS_ASSERT_MSG (rProto, "Ipv4 routing not installed on node");
  
  Ptr<DVRPRoutingProtocol> DVRP = DynamicCast<DVRPRoutingProtocol> (rProto);
  if (DVRP)
  {
    DVRP->AddDefaultRouteTo (nextHop, interface);
  }
  
  // DVRP may also be in a list
  Ptr<Ipv4ListRouting> routeList = DynamicCast<Ipv4ListRouting> (rProto);
  if (routeList)
  {
    int16_t priority;
    Ptr<Ipv4RoutingProtocol> listIpv4Proto;
    Ptr<DVRPRoutingProtocol> listDVRP;
    
    for (uint32_t i = 0; i < routeList->GetNRoutingProtocols (); i++)
    {
      listIpv4Proto = routeList->GetRoutingProtocol (i, priority);
      listDVRP = DynamicCast<DVRPRoutingProtocol> (listIpv4Proto);
      
      if (listDVRP)
      {
        DVRP->AddDefaultRouteTo (nextHop, interface);
        break;
      }
    }
  }
}

void
DVRPHelper::ExcludeInterface (Ptr<Node> node, uint32_t interface)
{
  std::map< Ptr<Node>, std::set<uint32_t> >::iterator it = m_interfaceExclusions.find (node);

  if (it == m_interfaceExclusions.end ())
  {
    std::set<uint32_t> interfaces;
    interfaces.insert (interface);

    m_interfaceExclusions.insert (std::make_pair (node, interfaces));
  }
  else
  {
    it->second.insert (interface);
  }
}

}

