/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
 #include <fstream>
 #include <iostream>
 #include "ns3/core-module.h"
 #include "ns3/network-module.h"
 #include "ns3/internet-module.h"
 #include "ns3/mobility-module.h"
#include "ns3/dsr-helper.h"
#include "ns3/dsr-main-helper.h"
#include "ns3/dsr-module.h"
#include "ns3/flow-monitor-module.h"
 #include "ns3/applications-module.h"
 #include "ns3/yans-wifi-helper.h"
 #include "ns3/flow-monitor-module.h"
#include "ns3/netanim-module.h"
#include "ns3/consalg-module.h"
#include <map>
#include <algorithm>
 using namespace ns3;
 using namespace dsr;
#define TOTAL_TIME 20.0
 
 NS_LOG_COMPONENT_DEFINE ("p2p-dsr");

class DHTNode
{
public:
	DHTNode(std::string ip, uint16_t port): m_ip(ip), m_port(port) {}
	std::string GetIP(void) {return m_ip;}
	uint16_t GetPort(void) {return m_port;}

	bool HasKey(std::string key) 
	{ 
		std::map<std::string, std::string>::iterator it;
		it = data.find(key);
		if (it != data.end())
			return true;
		else
			return false;
	}

	void AddKeyValuePair(std::string key, std::string value)
	{
		data.insert(std::pair<std::string, std::string>(key, value));
	}

	std::string GetValue(std::string key)
	{
		std::map<std::string, std::string>::iterator it;
		it = data.find(key);
		if (it != data.end())
			return it->second;
		else
			return std::string("");
	}

	void UpdateData(std::map<std::string, std::string> &newData)
	{
		data.insert(newData.begin(), newData.end());
	}

private:
	std::string m_ip;
	uint16_t m_port;
	std::map<std::string, std::string> data;
};

class DistributedHashTable 
{
public:
	DistributedHashTable();
	~DistributedHashTable();

	void InsertNode(std::string ip, uint16_t port);
	std::string Lookup(std::string key);
	std::string Insert(std::string key, std::string value);
	std::string Update(std::string key, std::string value);

private:
	std::vector<DHTNode *> nodes;
	uint32_t GetHash(std::string key);
};

DistributedHashTable::DistributedHashTable()
{

}

DistributedHashTable::~DistributedHashTable()
{
	for (uint32_t i = 0 ; i < nodes.size() ; i++)
		delete nodes[i];
	nodes.clear();
}

void DistributedHashTable::InsertNode(std::string ip, uint16_t port)
{
	DHTNode *node = new DHTNode(ip,port);
	nodes.push_back(node);
}

uint32_t DistributedHashTable::GetHash(std::string key)
{
	uint32_t hash = 5381;
	int c;

	for(int i = 0; i < key.length() ; i++)
	{
		c = key.at(i);
		hash = ((hash << 5) +hash ) + c;
	}
	
	return hash % nodes.size();
}

std::string DistributedHashTable::Lookup(std::string key)
{
	// Calculate hash of the key
	uint32_t nodeIdx = GetHash(key);

	// Lookup the value in the node
	std::string value = nodes[nodeIdx]->GetValue(key);

	return value;
}

std::string DistributedHashTable::Insert(std::string key, std::string value)
{
	// Calculate hash of the key
	uint32_t nodeIdx = GetHash(key);

	// Insert the key-value in the node
	nodes[nodeIdx]->AddKeyValuePair(key, value);

	return "OK";
}

std::string DistributedHashTable::Update(std::string key, std::string value)
{
	// Calculate hash of the key
	uint32_t nodeIdx = GetHash(key);

	// Update the key-value in the node
	nodes[nodeIdx]->AddKeyValuePair(key, value);

	return "OK";
}

 
 class RoutingExperiment
 {
 public:
   RoutingExperiment ();
   void Run (int nSinks, double txp, std::string CSVfileName);
   //static void SetMACParam (ns3::NetDeviceContainer & devices,
   //                                 int slotDistance);
   std::string CommandSetup (int argc, char **argv);
 
 private:
   Ptr<Socket> SetupPacketReceive (Ipv4Address addr, Ptr<Node> node);
 void SentPacket(Ptr<Socket> socket, uint32_t dataSent);
   void ReceivePacket (Ptr<Socket> socket);
   void CheckThroughput ();
 
   uint32_t port;
uint32_t bytesSentTotal;
  uint32_t bytesTotal;
  uint32_t packetsReceived;
  int64_t delayTotalMs;
 
   std::string m_CSVfileName;
   int m_nSinks;
   double m_txp;
   bool m_traceMobility;
  uint32_t m_numNodes;
      bool enableBYZANTINE;


  // Number of Byzfault nodes
  uint32_t num_Byzantine_faults;
 };
 
 RoutingExperiment::RoutingExperiment ()
   : port (9),
     bytesSentTotal (0),
     bytesTotal (0),
     packetsReceived (0),
      delayTotalMs(0),
     m_CSVfileName ("dsr-results.csv"),
     m_traceMobility (false),
     m_numNodes (50), //nodes can increase here 
     enableBYZANTINE (true),
     num_Byzantine_faults(5)
 {
 }
 
static inline std::string
PrintReceivedPacket (Ptr<Socket> socket, Ptr<Packet> packet)
{
  SocketAddressTag tag;
  bool found;
  found = packet->PeekPacketTag (tag);
  std::ostringstream oss;

  oss << Simulator::Now ().GetSeconds () << " " << socket->GetNode ()->GetId ();

  if (found)
    {
      InetSocketAddress addr = InetSocketAddress::ConvertFrom (tag.GetAddress ());
      oss << " received one packet from " << addr.GetIpv4 ();
    }
  else
    {
      oss << " received one packet!";
    }
  return oss.str ();
}

void
RoutingExperiment::ReceivePacket (Ptr<Socket> socket)
{
  Ptr<Packet> packet;
  while ((packet = socket->Recv ()))
    {
      bytesTotal += packet->GetSize ();
      packetsReceived += 1;
      NS_LOG_UNCOND (PrintReceivedPacket (socket, packet));

      //FIXME: we have added the timestamp tag to the packet
      //in the onoffapplication for delay calculation
      TimestampTag timestamp;
      if (packet->FindFirstMatchingByteTag (timestamp)) {
	      Time tx = timestamp.GetTimestamp ();
	      Time delay = Simulator::Now () - tx;
              delayTotalMs += delay.GetMilliSeconds();
      }

    }
}
 
void
RoutingExperiment::SentPacket(Ptr<Socket> socket, uint32_t dataSent)
{
   bytesSentTotal += dataSent;
}

void
RoutingExperiment::CheckThroughput ()
{
  double kbs = (bytesTotal * 8.0) / TOTAL_TIME/10000;
  double pdr = double(bytesTotal) / bytesSentTotal;
  int64_t avgDelayMs = delayTotalMs / packetsReceived; 

  bytesTotal = 0;
  bytesSentTotal = 0;
  delayTotalMs = 0;

  std::ofstream out (m_CSVfileName.c_str (), std::ios::app);

  out << (Simulator::Now ()).GetSeconds () << ","
      << kbs/(TOTAL_TIME - 1.0) << ","
      << packetsReceived << ","
      << m_nSinks << ","
      << m_txp << ","
      << pdr << ","
      << avgDelayMs << ""
      << std::endl;

  out.close ();
  packetsReceived = 0;
    std::cout << "  Packets Delivery Ratio: " << pdr << "%" << "\n";
    std::cout << "  Average PLR: " << 1-(pdr)<< " %" << "\n";
    std::cout << "  All Delay: " << (avgDelayMs)  << "\n";
    std::cout << "  Throughput: " << (kbs) << " Mbps" << "\n";
  Simulator::Schedule (Seconds (1.0), &RoutingExperiment::CheckThroughput, this);
}

Ptr<Socket>
RoutingExperiment::SetupPacketReceive (Ipv4Address addr, Ptr<Node> node)
{
  TypeId tid = TypeId::LookupByName ("ns3::UdpSocketFactory");
  Ptr<Socket> sink = Socket::CreateSocket (node, tid);
  InetSocketAddress local = InetSocketAddress (addr, port);
  sink->Bind (local);
  sink->SetRecvCallback (MakeCallback (&RoutingExperiment::ReceivePacket, this));

  return sink;
}
 
 std::string
 RoutingExperiment::CommandSetup (int argc, char **argv)
 {
 CommandLine cmd;
  cmd.AddValue ("CSVfileName", "The name of the CSV output file name", m_CSVfileName);
  cmd.AddValue ("traceMobility", "Enable mobility tracing", m_traceMobility);
  cmd.AddValue ("numNodes", "number of nodes in the network", m_numNodes);
  cmd.Parse (argc, argv);
  return m_CSVfileName;
 }
 
 int
 main (int argc, char *argv[])
 {
   RoutingExperiment experiment;
   std::string CSVfileName = experiment.CommandSetup (argc,argv);
 
   //blank out the last output file and write the column headers
  std::ofstream out (CSVfileName.c_str ());
  out << "SimulationSecond," <<
  "Throughput," <<
  "PacketsReceived," <<
  "NumberOfSinks," <<
  "TransmissionPower," <<
  "Packet Deliver Ratio" <<
  "Avg Delay Ms" <<
  std::endl;
  out.close ();
 
   int nSinks = 10;
   double txp = 7.5;
 
   experiment.Run (nSinks, txp, CSVfileName);
 }
 
 void
 RoutingExperiment::Run (int nSinks, double txp, std::string CSVfileName)
 {
   Packet::EnablePrinting ();
   m_nSinks = nSinks;
   m_txp = txp;
   m_CSVfileName = CSVfileName;
 
   uint32_t  size = m_numNodes;
 
   double TotalTime = TOTAL_TIME;
   std::string rate ("2048bps");
   std::string phyMode ("DsssRate11Mbps");
   std::string tr_name ("manet-routing-compare");
   int nodeSpeed = 20; //in m/s node speed 
   int nodePause = 0; //in s pausetime changes

 
   Config::SetDefault  ("ns3::OnOffApplication::PacketSize",StringValue ("64"));
   Config::SetDefault ("ns3::OnOffApplication::DataRate",  StringValue (rate));
 
   //Set Non-unicastMode rate to unicast mode
   Config::SetDefault ("ns3::WifiRemoteStationManager::NonUnicastMode",StringValue (phyMode));
 
   NodeContainer nodes;
   nodes.Create (size);
   NodeContainer ByzfaultNodes;
 
   // setting up wifi phy and channel using helpers
   WifiHelper wifi;
   wifi.SetStandard (WIFI_PHY_STANDARD_80211b);
 
   YansWifiPhyHelper wifiPhy =  YansWifiPhyHelper::Default ();
   YansWifiChannelHelper wifiChannel;
   wifiChannel.SetPropagationDelay ("ns3::ConstantSpeedPropagationDelayModel");
   wifiChannel.AddPropagationLoss ("ns3::FriisPropagationLossModel");
   wifiPhy.SetChannel (wifiChannel.Create ());
 
   // Add a mac and disable rate control
   WifiMacHelper wifiMac;
   wifi.SetRemoteStationManager ("ns3::ConstantRateWifiManager",
                                 "DataMode",StringValue (phyMode),
                                 "ControlMode",StringValue (phyMode));
 
   wifiPhy.Set ("TxPowerStart",DoubleValue (txp));
   wifiPhy.Set ("TxPowerEnd", DoubleValue (txp));
 
   wifiMac.SetType ("ns3::AdhocWifiMac");
   NetDeviceContainer adhocDevices = wifi.Install (wifiPhy, wifiMac, nodes);
 
   MobilityHelper mobilityAdhoc;
   int64_t streamIndex = 0; // used to get consistent mobility across scenarios
 
   ObjectFactory pos;
   pos.SetTypeId ("ns3::RandomRectanglePositionAllocator");
   pos.Set ("X", StringValue ("ns3::UniformRandomVariable[Min=0.0|Max=1500.0]"));
   pos.Set ("Y", StringValue ("ns3::UniformRandomVariable[Min=0.0|Max=1500.0]"));
 
   Ptr<PositionAllocator> taPositionAlloc = pos.Create ()->GetObject<PositionAllocator> ();
   streamIndex += taPositionAlloc->AssignStreams (streamIndex);
 
   std::stringstream ssSpeed;
   ssSpeed << "ns3::UniformRandomVariable[Min=0.0|Max=" << nodeSpeed << "]";
   std::stringstream ssPause;
   ssPause << "ns3::ConstantRandomVariable[Constant=" << nodePause << "]";
   mobilityAdhoc.SetMobilityModel ("ns3::RandomWaypointMobilityModel",
                                   "Speed", StringValue (ssSpeed.str ()),
                                   "Pause", StringValue (ssPause.str ()),
                                   "PositionAllocator", PointerValue (taPositionAlloc));
   mobilityAdhoc.SetPositionAllocator (taPositionAlloc);
   mobilityAdhoc.Install (nodes);
DistributedHashTable dht;

// Create a vector containing ip and port of each node
    std::vector<std::pair<std::string, uint16_t> > nodeAddresses;
 for (uint32_t i = 0; i < size; ++i)
    {
        std::string ip = "192.168.1." + std::to_string(i);
        uint16_t port = 5000 + i;

// Add the address pair to the vector
        nodeAddresses.push_back(std::make_pair(ip, port));
    }

// Insert the nodes to distributed hash table
    for (uint32_t i = 0; i < size; ++i)
        dht.InsertNode(nodeAddresses[i].first, nodeAddresses[i].second);

// Perform lookup, insert and update operations
    if (dht.Lookup("key_1") == "")
        dht.Insert("key_1", "value_1");
    else
        dht.Update("key_1", "value_2");

    if (enableBYZANTINE)
    {
        // Use a fixed seed value for deterministic random number generation
        std::mt19937 gen(123); // You can replace '123' with any desired seed value

        // Create a list of all node indices
        std::vector<uint32_t> allNodeIndices(size);
        for (uint32_t i = 0; i < size; ++i)
        {
            allNodeIndices[i] = i;
        }

        // Randomly shuffle the list to get a random order
        std::shuffle(allNodeIndices.begin(), allNodeIndices.end(), gen);

        // Select the first num_Byzfault_nodes indices as Byzfault nodes
        for (uint32_t i = 0; i < num_Byzantine_faults; ++i)
        {
            ByzfaultNodes.Add(nodes.Get(allNodeIndices[i]));
        }
    }
 
   streamIndex += mobilityAdhoc.AssignStreams (nodes, streamIndex);
   NS_UNUSED (streamIndex); // From this point, streamIndex is unused
   ConsalgHelper consalgHelper (size);
   DsrHelper dsr;
   DsrMainHelper dsrMain;
   Ipv4ListRoutingHelper list;
   InternetStackHelper internet;
     internet.Install (nodes);
       dsrMain.Install (dsr, nodes);
   
   NS_LOG_INFO ("assigning ip address");
 
   Ipv4AddressHelper addressAdhoc;
   addressAdhoc.SetBase ("10.1.1.0", "255.255.255.0");
   Ipv4InterfaceContainer adhocInterfaces;
   adhocInterfaces = addressAdhoc.Assign (adhocDevices);
 
   OnOffHelper onoff1 ("ns3::UdpSocketFactory",Address ());
   onoff1.SetAttribute ("OnTime", StringValue ("ns3::ConstantRandomVariable[Constant=1.0]"));
   onoff1.SetAttribute ("OffTime", StringValue ("ns3::ConstantRandomVariable[Constant=0.0]"));
 
   for (int i = 0; i < nSinks; i++)
     {
       Ptr<Socket> sink = SetupPacketReceive (adhocInterfaces.GetAddress (i), nodes.Get (i));
 
       AddressValue remoteAddress (InetSocketAddress (adhocInterfaces.GetAddress (i), port));
       onoff1.SetAttribute ("Remote", remoteAddress);
 
       Ptr<UniformRandomVariable> var = CreateObject<UniformRandomVariable> ();
       ApplicationContainer temp = onoff1.Install (nodes.Get (i + nSinks));
       onoff1.InstallSocketDataSentCB(nodes.Get (i + nSinks), MakeCallback (&RoutingExperiment::SentPacket, this));
       temp.Start (Seconds (var->GetValue (1.0,2.0)));
       temp.Stop (Seconds (TotalTime));
     }
 if (enableBYZANTINE) {
   for (uint32_t i = 0; i < ByzfaultNodes.GetN (); i++)
   {
    Ptr<Node> ByzfaultNode = ByzfaultNodes.Get (i);
    Ptr<dsr::DsrRouting> routingProtocol = ByzfaultNode->GetObject<dsr::DsrRouting> ();
    routingProtocol->SetBYZANTINEAttackEnable(enableBYZANTINE);
    routingProtocol->SetBYZANTINEAttackPacketDropPercentage(100);
   }
 }
  
 FlowMonitorHelper flowmon;
  Ptr<FlowMonitor> monitor = flowmon.InstallAll();



  AnimationInterface anim ("output-dsr.xml"); // Mandatory


  anim.EnablePacketMetadata(true);

for (uint32_t i = 0; i < nodes.GetN (); i++)
  {
    Ptr<Node> n = nodes.Get (i);
    anim.UpdateNodeSize(n->GetId (),20,20);
    anim.UpdateNodeColor (n->GetId (), 0, 0, 255);
  }

  for (uint32_t i = 0; i < ByzfaultNodes.GetN (); i++)
  {
    Ptr<Node> m = ByzfaultNodes.Get (i);
    anim.UpdateNodeColor (m->GetId (), 255, 0, 0);
  }
 
 
   NS_LOG_INFO ("Run Simulation.");
 
  
 
   Simulator::Stop (Seconds (TotalTime));
   Simulator::Run ();
   CheckThroughput ();

 
   Simulator::Destroy ();
 }
 
