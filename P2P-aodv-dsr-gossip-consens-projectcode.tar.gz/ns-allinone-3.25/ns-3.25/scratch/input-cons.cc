#include "ns3/core-module.h"
#include "ns3/internet-module.h"
#include "ns3/network-module.h"
#include "ns3/applications-module.h"
#include "ns3/wifi-module.h"
#include "ns3/mesh-module.h"
#include "ns3/mobility-module.h"
#include "ns3/mesh-helper.h"
#include "ns3/netanim-module.h"
#include "ns3/flow-monitor-helper.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/consalg-module.h"
#include "ns3/aodv-module.h"
#include "ns3/consalg-module.h"
#include "ns3/error-rate-model.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <typeinfo>
#include <time.h>
#include <unistd.h>
#include <map>
#include <algorithm>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("P2PScript");


class DHTNode
{
public:
	DHTNode(std::string ip, uint16_t port): m_ip(ip), m_port(port) {}
	std::string GetIP(void) {return m_ip;}
	uint16_t GetPort(void) {return m_port;}

	bool HasKey(std::string key) 
	{ 
		std::map<std::string, std::string>::iterator it;
		it = data.find(key);
		if (it != data.end())
			return true;
		else
			return false;
	}

	void AddKeyValuePair(std::string key, std::string value)
	{
		data.insert(std::pair<std::string, std::string>(key, value));
	}

	std::string GetValue(std::string key)
	{
		std::map<std::string, std::string>::iterator it;
		it = data.find(key);
		if (it != data.end())
			return it->second;
		else
			return std::string("");
	}

	void UpdateData(std::map<std::string, std::string> &newData)
	{
		data.insert(newData.begin(), newData.end());
	}

private:
	std::string m_ip;
	uint16_t m_port;
	std::map<std::string, std::string> data;
};

class DistributedHashTable 
{
public:
	DistributedHashTable();
	~DistributedHashTable();

	void InsertNode(std::string ip, uint16_t port);
	std::string Lookup(std::string key);
	std::string Insert(std::string key, std::string value);
	std::string Update(std::string key, std::string value);

private:
	std::vector<DHTNode *> nodes;
	uint32_t GetHash(std::string key);
};

DistributedHashTable::DistributedHashTable()
{

}

DistributedHashTable::~DistributedHashTable()
{
	for (uint32_t i = 0 ; i < nodes.size() ; i++)
		delete nodes[i];
	nodes.clear();
}

void DistributedHashTable::InsertNode(std::string ip, uint16_t port)
{
	DHTNode *node = new DHTNode(ip,port);
	nodes.push_back(node);
}

uint32_t DistributedHashTable::GetHash(std::string key)
{
	uint32_t hash = 5381;
	int c;

	for(int i = 0; i < key.length() ; i++)
	{
		c = key.at(i);
		hash = ((hash << 5) +hash ) + c;
	}
	
	return hash % nodes.size();
}

std::string DistributedHashTable::Lookup(std::string key)
{
	// Calculate hash of the key
	uint32_t nodeIdx = GetHash(key);

	// Lookup the value in the node
	std::string value = nodes[nodeIdx]->GetValue(key);

	return value;
}

std::string DistributedHashTable::Insert(std::string key, std::string value)
{
	// Calculate hash of the key
	uint32_t nodeIdx = GetHash(key);

	// Insert the key-value in the node
	nodes[nodeIdx]->AddKeyValuePair(key, value);

	return "OK";
}

std::string DistributedHashTable::Update(std::string key, std::string value)
{
	// Calculate hash of the key
	uint32_t nodeIdx = GetHash(key);

	// Update the key-value in the node
	nodes[nodeIdx]->AddKeyValuePair(key, value);

	return "OK";
}

class P2PSimulation
{
public:
  /// Init test
  P2PSimulation ();
  /// Configure test from command line arguments
  void Configure (int argc, char ** argv);
  /// Run test
  int Run ();
private:
  int       size;
  double xMax; 
  double yMax; 
  int velocity;//in m/s
  int nodePause; //in s
  double minv;//minimum velocity of node
  double    m_randomStart;
  double    m_totalTime;
  double    m_packetInterval;
  uint16_t  m_packetSize;
  uint32_t  m_nIfaces;
  bool      m_chan;
  bool      m_pcap;
  std::string m_stack;
  std::string m_root;
  /// List of network nodes
  NodeContainer nodes;
  NetDeviceContainer p2pDevices;
  Ipv4InterfaceContainer interfaces;
  MeshHelper p2p;
private:
  /// Create nodes and setup their mobility
  void CreateNodes ();
  /// Install internet m_stack on nodes
  void InstallInternetStack ();
  /// Install applications
  void InstallApplication ();

};
P2PSimulation::P2PSimulation () :
  size (20),
  xMax (500),
  yMax (500),
  velocity(5),
  nodePause(0),
  minv(0.1),
  m_randomStart (0.1),
  m_totalTime (50.0),
  m_packetInterval (0.1),
  m_packetSize (1024),
  m_nIfaces (1),
  m_chan (true),
  m_pcap (true),
  m_stack ("ns3::Dot11sStack"),
  m_root ("ff:ff:ff:ff:ff:ff")
{
}
void
P2PSimulation::Configure (int argc, char *argv[])
{
  CommandLine cmd;
  cmd.AddValue ("numnodes", "Number of nodes", size);
  /*
   * As soon as starting node means that it sends a beacon,
   * simultaneous start is not good.
   */
  cmd.AddValue ("start",  "Maximum random start delay, seconds. [0.1 s]", m_randomStart);
  cmd.AddValue ("time",  "Simulation time, seconds [100 s]", m_totalTime);
  cmd.AddValue ("packet-interval",  "Interval between packets in UDP ping, seconds [0.001 s]", m_packetInterval);
  cmd.AddValue ("packet-size",  "Size of packets in UDP ping", m_packetSize);
  cmd.AddValue ("interfaces", "Number of radio interfaces used by each p2p point. [1]", m_nIfaces);
  cmd.AddValue ("channels",   "Use different frequency channels for different interfaces. [0]", m_chan);
  cmd.AddValue ("stack",  "Type of protocol stack. ns3::Dot11sStack by default", m_stack);
  cmd.Parse (argc, argv);
  NS_LOG_DEBUG ("Simulation time: " << m_totalTime << " s");
}
void
P2PSimulation::CreateNodes ()
{

  nodes.Create (size);

  // Configure YansWifiChannel
  YansWifiPhyHelper wifiPhy = YansWifiPhyHelper::Default ();
  YansWifiChannelHelper wifiChannel = YansWifiChannelHelper::Default ();
  wifiPhy.SetChannel (wifiChannel.Create ());


  /*
   * Create p2p helper and set stack installer to it
   * Stack installer creates all needed protocols and install them to
   * p2p point device
   */
  p2p = MeshHelper::Default ();
  if (!Mac48Address (m_root.c_str ()).IsBroadcast ())
    {
      p2p.SetStackInstaller (m_stack, "Root", Mac48AddressValue (Mac48Address (m_root.c_str ())));
    }
  else
    {
      //If root is not set, we do not use "Root" attribute, because it
      //is specified only for 11s
      p2p.SetStackInstaller (m_stack);
    }
  if (m_chan)
    {
      p2p.SetSpreadInterfaceChannels (MeshHelper::SPREAD_CHANNELS);
    }
  else
    {
      p2p.SetSpreadInterfaceChannels (MeshHelper::ZERO_CHANNEL);
    }
  p2p.SetMacType ("RandomStart", TimeValue (Seconds (m_randomStart)));
  p2p.SetNumberOfInterfaces (m_nIfaces);
  p2pDevices = p2p.Install (wifiPhy,nodes);
 MobilityHelper mobility;
  ObjectFactory pos;
  pos.SetTypeId ("ns3::RandomRectanglePositionAllocator");
  std::ostringstream xpos, ypos;
  xpos << "ns3::UniformRandomVariable[Min=0.0|Max=" << xMax << "]";
  ypos << "ns3::UniformRandomVariable[Min=0.0|Max=" << yMax << "]";
  pos.Set ("X", StringValue (xpos.str()));
  pos.Set ("Y", StringValue (ypos.str()));

  Ptr<PositionAllocator> taPositionAlloc = pos.Create() ->GetObject<PositionAllocator> ();

  std::ostringstream randomSpeed, randomPause;
  randomSpeed << "ns3::UniformRandomVariable[Min=" << minv << "|Max=" << velocity << "]"; //<--avoid velocity of 0 m/s
  randomPause << "ns3::UniformRandomVariable[Min=0.0|Max=" << nodePause << "]";    
  mobility.SetMobilityModel ("ns3::RandomWaypointMobilityModel",
                                  "Speed", StringValue(randomSpeed.str()),
                                  "Pause", StringValue(randomPause.str()),
                                "PositionAllocator", PointerValue (taPositionAlloc));
  mobility.SetPositionAllocator(taPositionAlloc);

  mobility.Install (nodes);
DistributedHashTable dht;

// Create a vector containing ip and port of each node
    std::vector<std::pair<std::string, uint16_t> > nodeAddresses;
 for (uint32_t i = 0; i < size; ++i)
    {
        std::string ip = "192.168.1." + std::to_string(i);
        uint16_t port = 5000 + i;

// Add the address pair to the vector
        nodeAddresses.push_back(std::make_pair(ip, port));
    }

// Insert the nodes to distributed hash table
    for (uint32_t i = 0; i < size; ++i)
        dht.InsertNode(nodeAddresses[i].first, nodeAddresses[i].second);

// Perform lookup, insert and update operations
    if (dht.Lookup("key_1") == "")
        dht.Insert("key_1", "value_1");
    else
        dht.Update("key_1", "value_2");


}
void
P2PSimulation::InstallInternetStack ()
{
  LogComponentEnable ("ConsAlg", LOG_LEVEL_INFO);
  ConsalgHelper consalgHelper (size);
  InternetStackHelper internetStack;
  internetStack.Install (nodes);
  Ipv4AddressHelper address;
  address.SetBase ("10.1.1.0", "255.255.255.0");
  interfaces.Add(address.Assign (p2pDevices));
  for (int i = 0; i < size; i++) {
 for (int j = 0; j < size && j != i; j++) {
          consalgHelper.m_nodesConnectionsIps[i].push_back(interfaces.GetAddress(1));
          consalgHelper.m_nodesConnectionsIps[j].push_back(interfaces.GetAddress(0));
          address.NewNetwork();
         }
         }
  ApplicationContainer nodeApp = consalgHelper.Install (nodes);
  nodeApp.Start (Seconds (0.0));
  nodeApp.Stop (Seconds (m_totalTime));
  
}
void
P2PSimulation::InstallApplication ()
{
  
  UdpEchoServerHelper echoServer (9);
  ApplicationContainer serverApps = echoServer.Install (nodes.Get (0));
  serverApps.Start (Seconds (0.0));
  serverApps.Stop (Seconds (m_totalTime));
  UdpEchoClientHelper echoClient (interfaces.GetAddress (0), 9);
  echoClient.SetAttribute ("MaxPackets", UintegerValue ((uint32_t)(m_totalTime*(1/m_packetInterval))));
  echoClient.SetAttribute ("Interval", TimeValue (Seconds (m_packetInterval)));
  echoClient.SetAttribute ("PacketSize", UintegerValue (m_packetSize));
  ApplicationContainer clientApps = echoClient.Install (nodes.Get (size-1));
  clientApps.Start (Seconds (0.0));
  clientApps.Stop (Seconds (m_totalTime));
}
int
P2PSimulation::Run ()
{
  CreateNodes ();
  InstallInternetStack ();
  InstallApplication ();
  AnimationInterface animation ("output-cons.xml");
  animation.EnablePacketMetadata (false);
  for (uint32_t i = 0; i < size; i++)
  {
  animation.UpdateNodeSize(i,20,20);
  }
 //anim.UpdateNodeDescription (controllers.Get(i), "CN");
 //anim.UpdateNodeColor (controllers.Get(i), 0, 0, 255);

    FlowMonitorHelper flowmon;
  Ptr<FlowMonitor> monitor = flowmon.InstallAll();
  Simulator::Stop (Seconds (m_totalTime));
  Simulator::Run ();
   monitor->CheckForLostPackets();

  Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
  std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats();

  uint32_t txPacketsum = 0;
  uint32_t rxPacketsum = 0;
  uint32_t rxBytesum = 0;
  uint32_t DropPacketsum = 0;
  uint32_t LostPacketsum = 0;
  double Delaysum = 0;
  double hopcount_value = 0;

  for (std::map<FlowId, FlowMonitor::FlowStats>::const_iterator i = stats.begin(); i != stats.end(); ++i) {
    txPacketsum += i->second.txPackets;
    rxPacketsum += i->second.rxPackets;
    rxBytesum += i->second.rxBytes;
    LostPacketsum += i->second.lostPackets;
    DropPacketsum += i->second.packetsDropped.size();
    Delaysum += i->second.delaySum.GetSeconds();
    hopcount_value += i->second.timesForwarded;
  }

  std::cout << "************************************************************" << std::endl;
  std::cout << "Total Transmitted Packets: " << txPacketsum << std::endl;
  std::cout << "Total Received Packets: " << rxPacketsum << std::endl;
  std::cout << "Packet Delivery Ratio: " << ((rxPacketsum * 100.0) / txPacketsum) << "%" << std::endl;
  std::cout << "Average PLR: " << 100 - ((rxPacketsum * 100.0) / txPacketsum) << "%" << std::endl;
  std::cout << "Average Delay: " << (Delaysum / rxPacketsum) << " seconds" << std::endl;
  std::cout << "Throughput: " << ((rxBytesum * 8.0) / m_totalTime) / 1e6 << " Mbps" << std::endl;
  std::cout << "************************************************************" << std::endl;

  Simulator::Destroy ();
  return 0;
}

int
main (int argc, char *argv[])
{
  P2PSimulation t;
  t.Configure (argc, argv);
  return t.Run ();
}
